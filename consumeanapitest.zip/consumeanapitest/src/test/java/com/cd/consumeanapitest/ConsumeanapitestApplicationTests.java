package com.cd.consumeanapitest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumeanapitestApplicationTests {

	@Test
	void contextLoads() {
	}

}
