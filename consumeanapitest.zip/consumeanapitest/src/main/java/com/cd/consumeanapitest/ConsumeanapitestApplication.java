package com.cd.consumeanapitest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumeanapitestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsumeanapitestApplication.class, args);
	}

}
